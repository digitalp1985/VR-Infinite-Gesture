using System.Collections.Generic;
using System.IO;

namespace SymLinker.Editors
{
    public class LinkTargets
    {
        public class Target
        {
            public string LinkName;
            public string Path;
        }

        public readonly List<Target> Targets = new List<Target>();

        public static LinkTargets Load(string path)
        {
            if (!File.Exists(path)) return null;

            LinkTargets linkTargets = new LinkTargets();
            using (StreamReader StreamReader = new StreamReader(path))
            {
                while (!StreamReader.EndOfStream)
                {
                    string line = StreamReader.ReadLine().Trim();
                    if (string.IsNullOrEmpty(line)) continue;
                    var parts = line.Split(' ');
                    if (parts.Length < 2) continue;
                    Target record = new Target()
                    {
                        LinkName = parts[0],
                        Path = parts[1]
                    };

                    linkTargets.Targets.Add(record);
                }
            }

            return linkTargets;
        }

        public static void Save(LinkTargets linkTargets, string path)
        {
            using (StreamWriter streamWriter = new StreamWriter(path))
            {
                foreach (Target record in linkTargets.Targets)
                {
                    streamWriter.WriteLine("{0} {1}", record.LinkName, record.Path);
                }
            }
        }

        public static LinkTargets Create(string path)
        {
            LinkTargets linkTargets = new LinkTargets();
            Save(linkTargets, path);
            return linkTargets;
        }
    }
}