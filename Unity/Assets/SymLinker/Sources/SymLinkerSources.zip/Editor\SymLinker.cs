﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace SymLinker.Editors
{
    [InitializeOnLoad]
    public class SymLinker
    {
        private string _linkTargetsPath;
        private bool _includesFoldout = true;
        private LinkTargets _linkTargets;
        private SymLinkerProjectSettings _settings;

        private static SymLinker _instance = new SymLinker();

        public static SymLinker Instance
        {
            get { return _instance; }
        }

        private const string SlLinkTargetsPath = "SL_LinkTargets_Path";

        private static float _initializedAt;
        private static bool _started;

        static SymLinker()
        {
            EditorApplication.update += UpdateStatic;
            _initializedAt = Time.realtimeSinceStartup;
        }

        public EditorWindow CurrentWindow { get; set; }

        private static void UpdateStatic()
        {
            SymLinker.Instance.Update();
        }

        private void Update()
        {
            if (!_started && Time.realtimeSinceStartup - _initializedAt > 2f)
            {
                _started = true;
                AssetDatabase.Refresh();
                if (CurrentWindow != null)
                {
                    CurrentWindow.Focus();
                }
            }
        }

        public LinkTargets LinkTargets
        {
            get { return _linkTargets; }
        }

        public SymLinkerProjectSettings ProjectSettings
        {
            get { return _settings; }
        }

        public void Load()
        {
            if (_linkTargets == null)
            {
                _linkTargetsPath = EditorPrefs.GetString(SlLinkTargetsPath, null);
                _linkTargets = LinkTargets.Load(_linkTargetsPath);
            }

            if (_settings == null)
            {
                _settings = SymLinkerProjectSettings.Load();
            }
        }

        public void Save()
        {
            if (_linkTargets != null)
            {
                EditorPrefs.SetString(SlLinkTargetsPath, _linkTargetsPath);
                LinkTargets.Save(_linkTargets, _linkTargetsPath);
            }

            if (_settings != null)
            {
                SymLinkerProjectSettings.Save(_settings);
            }
        }

        private void EditLinkRecordsPath()
        {
            GUILayout.BeginHorizontal();
            EditorGUI.BeginChangeCheck();

            GUILayout.Label("Link Targets Path");
            GUILayout.Label(_linkTargetsPath);

            if (GUILayout.Button("...", GUILayout.Width(32)))
            {
                string path = _linkTargetsPath;
                if (!string.IsNullOrEmpty(_linkTargetsPath))
                {
                    path = Directory.GetParent(_linkTargetsPath).FullName;
                }
                path = EditorUtility.OpenFilePanel("Link targets path", path, "txt");
                if (!string.IsNullOrEmpty(path))
                {
                    _linkTargetsPath = path;
                }
            }

            if (EditorGUI.EndChangeCheck())
            {
                _linkTargets = LinkTargets.Load(_linkTargetsPath);
                if (_linkTargets != null)
                {
                    Save();
                }
            }

            GUILayout.EndHorizontal();
            if (GUILayout.Button("Create new Links Targets file"))
            {
                string path = null;
                if (String.IsNullOrEmpty(_linkTargetsPath))
                {
                    path = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                }
                else
                {
                    path = Directory.GetParent(_linkTargetsPath).FullName;
                }

                path = EditorUtility.SaveFilePanel("Link targets path", path, "LinkTargets.txt", "txt");
                if (!string.IsNullOrEmpty(path))
                {
                    LinkTargets.Create(path);
                    _linkTargetsPath = path;
                    _linkTargets = LinkTargets.Load(_linkTargetsPath);
                    Save();
                }
            }
        }

        private void EditLinkRecords(LinkTargets linkTargets)
        {
            var normColor = GUI.color;

            GUILayout.BeginHorizontal();
            GUILayout.Label("Name", GUILayout.Width(100));
            GUILayout.Label("Path");
            GUILayout.EndHorizontal();

            EditorGUI.BeginChangeCheck();
            LinkTargets.Target deleted = null;
            foreach (LinkTargets.Target linkRecord in _linkTargets.Targets)
            {
                GUILayout.BeginHorizontal();
                if (linkRecord.LinkName == null) linkRecord.LinkName = "";
                if (linkRecord.Path == null) linkRecord.Path = "";

                linkRecord.LinkName = GUILayout.TextField(linkRecord.LinkName, GUILayout.Width(100));

                if (!Directory.Exists(linkRecord.Path))
                {
                    GUI.color = Color.red;
                }

                linkRecord.Path = GUILayout.TextField(linkRecord.Path);

                GUI.color = normColor;

                if (GUILayout.Button("...", GUILayout.Width(32)))
                {
                    string path = linkRecord.Path;
                    if (string.IsNullOrEmpty(path) && !string.IsNullOrEmpty(_linkTargetsPath))
                    {
                        path = Directory.GetParent(_linkTargetsPath).FullName;
                    }

                    path = EditorUtility.OpenFolderPanel(linkRecord.LinkName + " path", path, "");
                    if (!string.IsNullOrEmpty(path))
                    {
                        linkRecord.Path = path;
                        if (string.IsNullOrEmpty(linkRecord.LinkName))
                        {
                            DirectoryInfo directoryInfo = new DirectoryInfo(path);
                            linkRecord.LinkName = (directoryInfo.Name);
                        }
                    }
                }
                if (GUILayout.Button("X", GUILayout.Width(32)))
                {
                    if (EditorUtility.DisplayDialog("Removing", "Remove " + linkRecord.LinkName + " link record?",
                        "Remove",
                        "Cancel"))
                    {
                        deleted = linkRecord;
                    }
                }
                GUILayout.EndHorizontal();
            }

            _linkTargets.Targets.Remove(deleted);

            if (GUILayout.Button("Add new target"))
            {
                _linkTargets.Targets.Add(new LinkTargets.Target());
            }

            if (EditorGUI.EndChangeCheck())
            {
                Save();
            }
        }

        private void EditProjectSettings(SymLinkerProjectSettings settings)
        {
            if (settings == null) return;
            var normColor = GUI.color;
            var liteColor = new Color(1f, 1f, 1f, 0.1f);
            var darkColor = new Color(0.5f, 0.5f, 0.5f, 0.1f);

            EditorGUILayout.LabelField("Include");

            EditorGUI.BeginChangeCheck();
            SymLinkerProjectSettings.IncludeRecord deleted = null;
            List<SymLinkerProjectSettings.IncludeRecord> records = settings.Records;

            int i = 0;
            foreach (SymLinkerProjectSettings.IncludeRecord record in records)
            {
                i++;
                var rect = EditorGUILayout.GetControlRect(false, 1, GUILayout.Width(Screen.width));
                rect.height = 25;
                GUI.color = i%2 == 0 ? liteColor : darkColor;
                GUI.Box(rect, GUIContent.none);
                GUI.color = normColor;

                EditorGUILayout.BeginHorizontal();
                record.Include = EditorGUILayout.ToggleLeft(record.LinkName, record.Include);
                if (GUILayout.Button("X", GUILayout.Width(32)))
                {
                    if (EditorUtility.DisplayDialog("Removing", "Remove " + record.LinkName + " inclusion?", "Remove",
                        "Cancel"))
                    {
                        deleted = record;
                    }
                }
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.Space();

            GUI.color = Color.cyan;
            if (_linkTargets != null)
            {
                foreach (var target in _linkTargets.Targets)
                {
                    if (records.Any(p => p.LinkName == target.LinkName)) continue;
                    if (EditorGUILayout.ToggleLeft(target.LinkName, false))
                    {
                        records.Add(new SymLinkerProjectSettings.IncludeRecord()
                        {
                            Include = true,
                            LinkName = target.LinkName
                        });
                    }
                }
            }
            GUI.color = normColor;
            records.Remove(deleted);

            if (EditorGUI.EndChangeCheck())
            {
                Save();
            }
        }

        private static bool IsUnix
        {
            get
            {
                int p = (int) Environment.OSVersion.Platform;
                return (p == 4) || (p == 6) || (p == 128);
            }
        }

        private class ScriptInfo
        {
            public bool Include;
            public string TargetPath;
            public string LinkPath;
        }

        private List<ScriptInfo> BuildScriptInfos()
        {
            List<ScriptInfo> infos = new List<ScriptInfo>();

            foreach (SymLinkerProjectSettings.IncludeRecord includeRecord in _settings.Records)
            {
                ScriptInfo info = new ScriptInfo();

                info.Include = includeRecord.Include;

                LinkTargets.Target target =
                    _linkTargets.Targets.FirstOrDefault(p => p.LinkName == includeRecord.LinkName);

                if (target != null)
                {
                    info.TargetPath = CleanPath(target.Path);
                }

                string symlinkPath = Path.Combine(Application.dataPath, "SymLinks");
                symlinkPath = Path.Combine(symlinkPath, includeRecord.LinkName);

                info.LinkPath = CleanPath(symlinkPath);

                infos.Add(info);
            }

            return infos;
        }

        private string CleanPath(string path)
        {
            return path.Replace('/', Path.DirectorySeparatorChar)
                .Replace('\\', Path.DirectorySeparatorChar);
        }

        private string BuildScript(List<ScriptInfo> infos)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var info in infos)
            {
                sb.AppendLine(BuildRemoveSymLinkCmdLine(info.LinkPath));

                if (info.Include)
                {
                    if (!String.IsNullOrEmpty(info.TargetPath))
                    {
                        sb.AppendLine(BuildSymLinkCmdLine(info.TargetPath, info.LinkPath));
                    }
                }
            }

            return sb.ToString();
        }

        private void ExecuteScript(string script)
        {
            string symlinksPath = CleanPath(Path.Combine(Application.dataPath, "SymLinks"));

            try
            {
                Directory.Delete(symlinksPath, true);
            }
            catch
            {
                //directory is in use
            }

            if (!Directory.Exists(symlinksPath))
            {
                Directory.CreateDirectory(symlinksPath);
            }

            if (IsUnix)
            {
                script = script.Trim().Replace("\n", "&");

                var proc = new ProcessStartInfo();
                proc.UseShellExecute = true;
                proc.FileName = @"/bin/bash";
                proc.Arguments = "-c '" + script + "'";
                Process.Start(proc);
            }
            else
            {
                script = script.Trim().Replace("\n", "&");

                var proc = new ProcessStartInfo();
                proc.UseShellExecute = true;
                proc.FileName = @"cmd.exe";
                proc.Verb = "runas";
                proc.Arguments = "/K " + script;
                Process.Start(proc);
            }

            AssetDatabase.Refresh();
        }

        private string BuildSymLinkCmdLine(string targetPath, string symlinkPath)
        {
            if (IsUnix)
            {
                return String.Format("ln -s \"{0}\" \"{1}\"", targetPath, symlinkPath);
            }
            else
            {
                return String.Format("MKLINK /D \"{0}\" \"{1}\"", symlinkPath, targetPath);
            }
        }

        private string BuildRemoveSymLinkCmdLine(string symlinkPath)
        {
            if (IsUnix)
            {
                return String.Format("unlink \"{0}\"", symlinkPath);
            }
            else
            {
                return String.Format("rmdir \"{0}\"", symlinkPath);
            }
        }

        public static ScriptableObject CreateAsset(Type type, string name)
        {
            if (Application.isPlaying) return null;
            ScriptableObject asset = ScriptableObject.CreateInstance(type);
            string assetPathAndName = AssetDatabase.GenerateUniqueAssetPath("Assets/" + name + ".asset");
            AssetDatabase.CreateAsset(asset, assetPathAndName);
            AssetDatabase.SaveAssets();
            return asset;
        }

        public void OnInspector()
        {
            EditLinkRecordsPath();

            if (_linkTargets != null)
            {
                EditLinkRecords(_linkTargets);
            }

            if (_settings == null) return;

            _includesFoldout = EditorGUILayout.Foldout(_includesFoldout, "Project Settings");
            if (_includesFoldout)
            {
                EditProjectSettings(_settings);
            }

            if (_linkTargets == null)
            {
                EditorGUILayout.HelpBox("Link records not found", MessageType.Warning);
                return;
            }

            var infos = BuildScriptInfos();
            var script = BuildScript(infos);

            EditScript(script);


            if (!_started)
            {
                GUI.enabled = false;
            }

            if (GUILayout.Button("Execute script"))
            {
                ExecuteScript(script);
                _started = false;
                _initializedAt = Time.realtimeSinceStartup;
            }
        }

        private void EditScript(string script)
        {
            var normColor = GUI.color;
            GUI.color = Color.cyan;
            GUILayout.TextArea(script);
            GUI.color = normColor;
        }
    }
}