using UnityEditor;
using UnityEngine;

namespace SymLinker.Editors
{
    public class SymLinkerWindow : EditorWindow
    {
        [SerializeField] private Vector2 scrollPos;
        [SerializeField] private float height = 100;

        public SymLinker SymLinker
        {
            get { return SymLinker.Instance; }
        }

		[MenuItem("Tools/SymLinker/Settings")]
        public static void OpenGameManagerWindow()
        {
            SymLinkerWindow.Open();
        }

        public void OnSelectionChange()
        {
            Repaint();
        }


        public static SymLinkerWindow Open()
        {
            SymLinkerWindow window = EditorWindow.GetWindow(typeof (SymLinkerWindow)) as SymLinkerWindow;
            window.titleContent = new GUIContent("SymLinker");
			SymLinker.Instance.CurrentWindow = window;
            return window;
        }

        public void OnFocus()
        {
            Repaint();
            SymLinker.Load();
        }

        public void OnGUI()
        {
            var oldHeight = height;

            scrollPos = GUI.BeginScrollView(new Rect(0, 0, position.width, position.height), scrollPos,
                new Rect(0, 0, 0, height));

            if (!EditorApplication.isPlayingOrWillChangePlaymode)
            {
                OnInspector();
            }

            var r = EditorGUILayout.BeginVertical();
            EditorGUILayout.LabelField("", GUILayout.Height(0.0f));
            EditorGUILayout.EndVertical();

            if (Event.current.type == EventType.Repaint)
            {
                height = r.y;
            }

            GUI.EndScrollView();

            if (GUI.changed == true || oldHeight != height)
            {
                Repaint();
            }
        }

        public void OnInspector()
        {
			if (SymLinker.Instance.CurrentWindow == null) 
			{
				SymLinker.Instance.CurrentWindow = this;
			}
            SymLinker.OnInspector();
        }
    }
}