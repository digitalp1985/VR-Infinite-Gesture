using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace SymLinker.Editors
{
    public class SymLinkerProjectSettings
    {
        [Serializable]
        public class IncludeRecord
        {
            public bool Include;
            public string LinkName;
        }

        public static string FilePath
        {
            get
            {
                return Application.dataPath + "/" + typeof(SymLinkerProjectSettings).Name + ".txt";
            }
        }

        public static SymLinkerProjectSettings Load()
        {
            SymLinkerProjectSettings settings = new SymLinkerProjectSettings();
            if (!File.Exists(FilePath))
            {
                return settings;
            }

            using (StreamReader streamReader = new StreamReader(FilePath))
            {
                while (!streamReader.EndOfStream)
                {
                    string line = streamReader.ReadLine().Trim();
                    if (string.IsNullOrEmpty(line)) continue;
                    var parts = line.Split(' ');
                    if (parts.Length < 2) continue;
                    IncludeRecord record = new IncludeRecord()
                    {
                        Include = parts[0]=="+"?true:false,
                        LinkName = parts[1]
                    };

                    settings.Records.Add(record);
                }
            }

            return settings;
        }

        public static void Save(SymLinkerProjectSettings settings)
        {
            using (StreamWriter streamWriter = new StreamWriter(FilePath))
            {
                foreach (IncludeRecord record in settings.Records)
                {
                    streamWriter.WriteLine("{0} {1}", record.Include ? "+" : "-", record.LinkName);
                }
            }
        }

        public List<IncludeRecord> Records = new List<IncludeRecord>();
    }
}