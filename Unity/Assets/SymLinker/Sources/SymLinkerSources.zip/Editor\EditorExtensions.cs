using UnityEditor;

namespace SymLinker.Editors
{
    public static class EditorExtensions
    {
        private const string thread = "http://edentec.org/unity/symlinker/thread";
        private const string docs = "http://edentec.org//unity/symlinker/docs";
        
        [MenuItem("Tools/SymLinker/Unity forums thread")]
        private static void OpenThread()
        {
            Help.BrowseURL(thread);
        }

        [MenuItem("Tools/SymLinker/Docs")]
        private static void OpenDocs()
        {
            Help.BrowseURL(docs);
        }
    }
}